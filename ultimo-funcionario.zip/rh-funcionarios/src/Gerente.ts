import Funcionario from './Funcionario'

export default class Gerente extends Funcionario {

    private departamento: string = ""
    private funcionariosGerenciados: string[] = []
    private readonly BONUS: number = 0.2

    constructor(nome: string, salarioBase: number, departamento: string, funcionariosGerenciados: string[]) {
        super(nome, salarioBase)
        this.setDepartamento(departamento)
        this.setFuncionariosGerenciados(funcionariosGerenciados)
    }

    getDepartamento(): string {
        return this.departamento
    }

    setDepartamento(departamento: string): void {
        if (departamento.length >= 2) {
            this.departamento = departamento
        } else {
            console.log("O nome do departamento deve ter pelo menos 2 caracteres.")
        }
    }

    getFuncionariosGerenciados(): string[] {
        return this.funcionariosGerenciados
    }

    setFuncionariosGerenciados(funcionariosGerenciados: string[]): void {
        this.funcionariosGerenciados = funcionariosGerenciados
    }

    calcularSalario(): number {
        return this.getSalarioBase() + (this.getSalarioBase() * this.BONUS)
    }

    imprimeInfo(): void {
        super.imprimeInfo()
        console.log("Departamento: " + this.departamento)
        console.log("Funcionários gerenciados: " + this.funcionariosGerenciados.join(", "))
    }
}
