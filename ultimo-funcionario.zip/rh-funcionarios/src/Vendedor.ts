import Funcionario from './Funcionario'

export default class Vendedor extends Funcionario {

    private departamento: string = ""
    private escalaTrabalho: string = ""
    private totalVendas: number = 0
    private readonly PERCENTUAL_COMISSAO: number = 0.1

    constructor(nome: string, salarioBase: number, departamento: string, escalaTrabalho: string, totalVendas: number) {
        super(nome, salarioBase)
        this.setDepartamento(departamento)
        this.setEscalaTrabalho(escalaTrabalho)
        this.setTotalVendas(totalVendas)
    }

    getDepartamento(): string {
        return this.departamento
    }

    setDepartamento(departamento: string): void {
        if (departamento.length >= 2) {
            this.departamento = departamento
        } else {
            console.log("O nome do departamento deve ter pelo menos 2 caracteres.")
        }
    }

    getEscalaTrabalho(): string {
        return this.escalaTrabalho
    }

    setEscalaTrabalho(escalaTrabalho: string): void {
        this.escalaTrabalho = escalaTrabalho
    }

    getTotalVendas(): number {
        return this.totalVendas
    }

    setTotalVendas(totalVendas: number): void {
        if (totalVendas >= 0) {
            this.totalVendas = totalVendas
        } else {
            console.log("O total de vendas não pode ser negativo.")
        }
    }

    calcularSalario(): number {
        return this.getSalarioBase() + (this.totalVendas * this.PERCENTUAL_COMISSAO)
    }

    imprimeInfo(): void {
        super.imprimeInfo()
        console.log("Departamento: " + this.departamento)
        console.log("Escala de trabalho: " + this.escalaTrabalho)
        console.log("Total de vendas: R$ " + this.totalVendas.toFixed(2))
    }
}
