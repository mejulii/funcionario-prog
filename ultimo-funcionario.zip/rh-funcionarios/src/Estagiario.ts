import Funcionario from './Funcionario'

export default class Estagiario extends Funcionario {

    private horasPorDia: number = 0

    constructor(nome: string, salarioBase: number, horasPorDia: number) {
        super(nome, salarioBase)
        this.setHorasPorDia(horasPorDia)
    }

    getHorasPorDia(): number {
        return this.horasPorDia
    }

    setHorasPorDia(horasPorDia: number): void {
        if (horasPorDia > 0 && horasPorDia <= 8) {
            this.horasPorDia = horasPorDia
        } else {
            console.log("As horas por dia devem estar entre 1 e 8.")
        }
    }

    calcularSalario(): number {
        return this.getSalarioBase()
    }

    imprimeInfo(): void {
        super.imprimeInfo()
        console.log("Horas de trabalho por dia: " + this.horasPorDia)
    }
}
