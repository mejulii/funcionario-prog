import Gerente from './Gerente'
import Vendedor from './Vendedor'
import Estagiario from './Estagiario'

let gerente1 = new Gerente(
    "Marcos Alves",
    6000,
    "Financeiro",
    ["Ana Costa", "Bruno Lima"]
)

let gerente2 = new Gerente(
    "Patricia Souza",
    6500,
    "Comercial",
    ["Carla Dias"]
)

let vendedor1 = new Vendedor(
    "Ana Costa",
    2000,
    "Comercial",
    "6x1",
    8000
)

let vendedor2 = new Vendedor(
    "Bruno Lima",
    2200,
    "Comercial",
    "5x2",
    5000
)

let estagiario1 = new Estagiario(
    "Carla Dias",
    1200,
    6
)

let estagiario2 = new Estagiario(
    "Diego Nunes",
    1200,
    4
)

console.log("===== GERENTE =====")
gerente1.imprimeInfo()

console.log("")

console.log("===== GERENTE =====")
gerente2.imprimeInfo()

console.log("")

console.log("===== VENDEDOR =====")
vendedor1.imprimeInfo()

console.log("")

console.log("===== VENDEDOR =====")
vendedor2.imprimeInfo()

console.log("")

console.log("===== ESTAGIÁRIO =====")
estagiario1.imprimeInfo()

console.log("")

console.log("===== ESTAGIÁRIO =====")
estagiario2.imprimeInfo()

console.log("")

let funcionarios = [gerente1, gerente2, vendedor1, vendedor2, estagiario1, estagiario2]

function somarSalarios(lista: (Gerente | Vendedor | Estagiario)[]): number {
    let total = 0
    for (let funcionario of lista) {
        total += funcionario.calcularSalario()
    }
    return total
}

console.log("===== TOTAL DA FOLHA =====")
console.log("Soma total dos salários: R$ " + somarSalarios(funcionarios).toFixed(2))
