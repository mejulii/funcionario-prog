export default abstract class Funcionario {

    private nome: string = ""
    private salarioBase: number = 0

    constructor(nome: string, salarioBase: number) {
        this.setNome(nome)
        this.setSalarioBase(salarioBase)
    }

    getNome(): string {
        return this.nome
    }

    setNome(nome: string): void {
        if (nome.length >= 3) {
            this.nome = nome
        } else {
            console.log("O nome deve ter pelo menos 3 caracteres.")
        }
    }

    getSalarioBase(): number {
        return this.salarioBase
    }

    setSalarioBase(salarioBase: number): void {
        if (salarioBase >= 0) {
            this.salarioBase = salarioBase
        } else {
            console.log("Salário base não pode ser negativo.")
        }
    }

    abstract calcularSalario(): number

    imprimeInfo(): void {
        console.log("Nome: " + this.nome)
        console.log("Salário calculado: R$ " + this.calcularSalario().toFixed(2))
    }
}
