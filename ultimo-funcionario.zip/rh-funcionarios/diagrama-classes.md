# Diagrama de Classes - Sistema de RH

Cole o bloco abaixo em https://mermaid.live para ver o diagrama desenhado.

```mermaid
classDiagram
    class Funcionario {
        <<abstract>>
        #nome: string
        #salarioBase: number
        +getNome() string
        +exibirDados() string
        +calcularSalario()* number
    }

    class Gerente {
        -departamento: string
        -funcionariosGerenciados: string[]
        -BONUS: number
        +calcularSalario() number
        +getDepartamento() string
        +getFuncionariosGerenciados() string[]
    }

    class Vendedor {
        -departamento: string
        -escalaTrabalho: string
        -totalVendas: number
        -PERCENTUAL_COMISSAO: number
        +calcularSalario() number
        +getDepartamento() string
        +getEscalaTrabalho() string
    }

    class Estagiario {
        -horasPorDia: number
        +calcularSalario() number
        +getHorasPorDia() number
    }

    Funcionario <|-- Gerente
    Funcionario <|-- Vendedor
    Funcionario <|-- Estagiario
```

## Versão em texto simples (para desenhar à mão)

```
              Funcionario (abstrata)
              ----------------------
              # nome
              # salarioBase
              + getNome()
              + exibirDados()
              + calcularSalario()  [abstrato]
                      |
        --------------|--------------
        |              |              |
     Gerente        Vendedor      Estagiario
     -------        --------      ----------
     - departamento   - departamento   - horasPorDia
     - funcionariosGerenciados
                      - escalaTrabalho
                      - totalVendas
     + calcularSalario()  + calcularSalario()  + calcularSalario()
```

A seta `Funcionario <|-- Gerente` significa "Gerente herda de Funcionario"
(a mesma leitura vale para Vendedor e Estagiario).
