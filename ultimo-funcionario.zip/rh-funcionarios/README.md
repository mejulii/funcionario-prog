# Sistema de RH - Cadastro de Funcionários

Explicação completa do projeto, arquivo por arquivo.

## 1. Estrutura de pastas

```
rh-funcionarios/
  src/               -> onde você escreve o código (.ts)
    Funcionario.ts
    Gerente.ts
    Vendedor.ts
    Estagiario.ts
    index.ts
  dist/              -> código já traduzido para JavaScript (gerado pelo tsc)
  diagrama-classes.png / .drawio / .md -> o diagrama de classes
  tsconfig.json      -> configurações do TypeScript
  package.json
  README.md          -> este arquivo
```

Você só mexe na pasta `src`. A pasta `dist` é gerada sozinha quando você
manda compilar (explico o comando lá embaixo).

## 2. Por que cada arquivo existe

### Funcionario.ts (a classe-mãe)

É uma "classe abstrata". Isso quer dizer duas coisas:

1. Ninguém consegue fazer `new Funcionario(...)` direto. Ela só serve de
   molde para as outras (Gerente, Vendedor, Estagiario).
2. Ela tem um método `calcularSalario()` sem corpo (sem código dentro).
   Isso obriga toda classe filha a escrever o seu próprio jeito de
   calcular salário.

Essa classe guarda o que é igual para todo mundo: `nome` e `salarioBase`.
Cada campo tem um par de métodos `getX()` / `setX()`. O `set` sempre
confere se o valor faz sentido antes de guardar (por exemplo, o nome
precisa ter pelo menos 3 letras); se não fizer sentido, ele avisa no
console e não altera o valor.

### Gerente.ts, Vendedor.ts, Estagiario.ts (as classes filhas)

Cada uma:

- Usa `extends Funcionario` para "herdar" nome, salarioBase e os
  métodos da classe-mãe.
- Usa `super(nome, salarioBase)` dentro do construtor para inicializar
  o que veio da classe-mãe.
- Chama seus próprios `setX(...)` no construtor para guardar (com
  validação) os campos extras dela.
- Escreve sua própria versão de `calcularSalario()`:
  - Gerente: salário base + 20% de bônus.
  - Vendedor: salário base + 10% sobre o total de vendas.
  - Estagiario: só recebe o valor fixo da bolsa.
- Escreve sua própria versão de `imprimeInfo()`, que primeiro chama
  `super.imprimeInfo()` (a versão da classe-mãe) e depois imprime os
  dados extras dela.

### index.ts (onde tudo roda)

1. Cria 2 objetos de cada classe (`new Gerente(...)`, `new Vendedor(...)`,
   `new Estagiario(...)`).
2. Chama `imprimeInfo()` de cada um, mostrando os dados no console.
3. Coloca todos dentro de um array `funcionarios`.
4. Tem a função `somarSalarios`, que percorre o array e soma o resultado
   de `calcularSalario()` de cada um.
5. No final, imprime o total da folha de pagamento.

## 3. Os 4 princípios da POO, onde estão no código

- **Abstração**: `Funcionario` é abstrata. Ela define "o que é" um
  funcionário sem se preocupar com os detalhes de cada tipo.
- **Encapsulamento**: todos os campos (`nome`, `salarioBase`,
  `departamento`, etc.) são `private`. Ninguém de fora acessa ou altera
  esses valores direto; só através dos métodos `getX()` / `setX()`, que
  ainda validam o valor antes de guardar.
- **Herança**: `Gerente`, `Vendedor` e `Estagiario` usam
  `extends Funcionario` e reaproveitam nome, salarioBase, getNome() e
  imprimeInfo() sem precisar reescrever do zero.
- **Polimorfismo**: a função `somarSalarios` e o `imprimeInfo()` chamam
  `calcularSalario()` sem saber se é um Gerente, Vendedor ou Estagiario.
  Cada objeto "sabe" qual versão do método usar sozinho.

## 4. Como rodar o projeto

Você precisa ter o Node.js instalado no computador. Depois:

```
cd rh-funcionarios
npm install
npm run build
npm start
```

- `npm install` baixa o TypeScript (só precisa fazer isso uma vez).
- `npm run build` traduz os arquivos de `src` para `dist` (em JavaScript).
- `npm start` roda o programa e mostra o resultado no terminal.

Se quiser só compilar sem rodar: `npx tsc`.
Se quiser rodar sem compilar de novo: `node dist/index.js`.

## 5. Como alterar o projeto (passo a passo)

### Mudar um valor (ex: bônus do gerente)

Abra `src/Gerente.ts` e mude a linha:

```ts
private readonly BONUS: number = 0.2
```

Troque `0.2` pelo valor que quiser (ex: `0.25` = 25%).

### Adicionar um novo funcionário

Abra `src/index.ts` e adicione um bloco novo, por exemplo:

```ts
let vendedor3 = new Vendedor(
    "Fulano",
    2100,
    "Comercial",
    "6x1",
    3000
)
```

Depois adicione um `console.log` para mostrar ele:

```ts
console.log("===== VENDEDOR =====")
vendedor3.imprimeInfo()
```

E inclua `vendedor3` dentro do array `funcionarios`:

```ts
let funcionarios = [gerente1, gerente2, vendedor1, vendedor2, vendedor3, estagiario1, estagiario2]
```

### Criar um novo tipo de funcionário (ex: Diretor)

1. Crie o arquivo `src/Diretor.ts`.
2. Escreva, seguindo o mesmo padrão das outras classes:

```ts
import Funcionario from './Funcionario'

export default class Diretor extends Funcionario {

    private participacaoLucro: number = 0

    constructor(nome: string, salarioBase: number, participacaoLucro: number) {
        super(nome, salarioBase)
        this.setParticipacaoLucro(participacaoLucro)
    }

    getParticipacaoLucro(): number {
        return this.participacaoLucro
    }

    setParticipacaoLucro(participacaoLucro: number): void {
        if (participacaoLucro >= 0) {
            this.participacaoLucro = participacaoLucro
        } else {
            console.log("A participação no lucro não pode ser negativa.")
        }
    }

    calcularSalario(): number {
        return this.getSalarioBase() + this.participacaoLucro
    }

    imprimeInfo(): void {
        super.imprimeInfo()
        console.log("Participação no lucro: R$ " + this.participacaoLucro.toFixed(2))
    }
}
```

3. No `index.ts`, importe e use igual aos outros:

```ts
import Diretor from './Diretor'

let diretor1 = new Diretor("Fulano", 10000, 3000)
```

4. Adicione `diretor1` no array `funcionarios`.
5. Rode `npm run build` e `npm start` de novo.

Sempre que mudar algo em `src`, é preciso rodar `npm run build` (ou
`npx tsc`) antes de rodar `npm start`, senão o `dist` fica desatualizado.

## 6. Como explicar isso em sala (resumo curto)

"Tenho uma classe abstrata Funcionario com nome e salário base, cada um
com seu get e set (o set valida o dado antes de guardar). As três
classes filhas (Gerente, Vendedor, Estagiario) herdam dela e cada uma
implementa o método calcularSalario() do seu próprio jeito. Isso é
herança e polimorfismo. Os campos são todos privados, então só acesso
por método, isso é encapsulamento. E a classe-mãe é abstrata, então
nunca crio um Funcionario 'genérico', só os tipos concretos, isso é
abstração. No index.ts eu crio os objetos, imprimo os dados de cada um
e somo os salários com a função somarSalarios, que chama
calcularSalario() de cada um sem precisar saber qual tipo é cada
objeto."
